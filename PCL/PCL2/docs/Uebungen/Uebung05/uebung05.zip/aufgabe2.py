#!/usr/bin/python
#-*- coding: utf-8 -*- 
#PCL 2, Uebung 05
#Aufgabe 2 Skelett


from nltk.corpus import brown
import re, string, nltk
from collections import defaultdict

rePunct = re.compile("^[" + string.punctuation + "]*$")
reNum = re.compile("^[0-9]*$")
matrix = defaultdict(lambda: defaultdict(float))

def single_cost(token):
	global rePunct
	
	#Your code goes here

def compare_cost(x,y):
	global rePunct,reNum
	
	#Your code goes here

def lev_word(a,b):
	global matrix
	
	#Your code goes here

def main():
	global matrix

	#Your code goes here


if __name__ == "__main__":
	main()



