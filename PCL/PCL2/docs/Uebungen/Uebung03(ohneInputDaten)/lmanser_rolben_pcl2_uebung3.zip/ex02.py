#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# PCL-I: Uebung 03 - Aufgabe 2, FS16
#
# Autoren:
# c(Student, Martikelnummer) -> {'Roland Benz'	: '97-923-163',
#								 'Linus Manser' : '13-791-132'}
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# with import no code should be running
# (only forward declaration of classes and functions)
# instead of converting every other int to floats,
# we decided to "cheat" and imported division
from __future__ import division
import ex01
import time

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Main
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# set the flags for debug info, and data structure
debug=0
ds1=0 #data structure 1){k-gram:{word:value}}

# if ds1=1 then ds2=0 and vice versa
ds2=(ds1+1)%2 #data structure 2){k-gram:(k,{word:value})}


def main():
	print "~~~~~~~~~~~~Aufgabe 2~~~~~~~~~~~~~"
	#load ham spam corpus
	# -------------------
	ham_spam_corpus, ham_corpus, spam_corpus, test_corpus = \
		ex01.own_corpus_reader()
	nr_of_documents_loaded = len(ham_spam_corpus.fileids())
	print ham_spam_corpus
	print "nr of documents", nr_of_documents_loaded

	# build data structure containing n-grams
	# ---------------------------------------
	# 1){k-gram:{word:value}}
	# 2){k-gram:(k,{word:value})}
	# n-gram = k-gram + word
	# value: absolute count of n-gram
	start = time.time() #time measurment

	if (ds1):dict_i_to_j_gram_keys = {0: {0: 0}} #dummy element
	if (ds2):dict_i_to_j_gram_keys = {0: (0,{0: 0})}  # dummy element
	dict_i_to_j_gram_keys, corpus_words = \
		build_i_gram_to_j_gram_keys(ham_spam_corpus, 1, 3)
	dict_i_to_j_gram_keys.pop(0, None) #remove dummy element

	end = time.time() #time measurment
	elapsed_time = end - start #time measurment

	if (debug): print_list(corpus_words)
	print "nr of tokens:", len(corpus_words), \
		"\ntime to build n-grams:", elapsed_time
	build_dict_test(dict_i_to_j_gram_keys, 1)

	# Exercise 2a) - 2e)
	# ---------------------------------------
	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "2a) checks whether the k-gram key exists"
	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	kgram="Subject :" #input
 	out = k_gram_exists(dict_i_to_j_gram_keys, kgram)
	print "ngram <%s> exists: %s" %(kgram, out)

	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "2b) prints the n-grams = words given k-gram"
	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	kgram = "Subject :" #input
 	out = print_n_grams(dict_i_to_j_gram_keys, kgram)
	print "List of n-grams = words given k-gram <%s>: " %(kgram)
	print out

	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "2c) uncond. probability of k-gram"
	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	kgram = "Subject :" #input

	#unconditional with respect to k-grams of same length k
	k = len(kgram.split())
	kgrams_cnt = len(corpus_words) + 1 - k
	print "kgrams_cnt = total_words + 1 - k: ", kgrams_cnt

	prob, kgram_cnt = unconditional_prob_of_k_gram(
		dict_i_to_j_gram_keys, kgram, kgrams_cnt)

	print "count of k-gram <%s> = %s" % (kgram, kgram_cnt)
	print "unconditional probabilty of k-gram <%s> = %s" %(kgram, prob)

	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "2d) cond. probability of word given kgram"
	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	kgram = "Subject" #input
	word = ":" #input

	(prob, cond_word_cnt, kgram_cnt) = \
		conditional_prob_of_word_given_k_gram\
			(dict_i_to_j_gram_keys, kgram, word )

	print "count of k-gram <%s> = %s" % (kgram, kgram_cnt)
	print "conditional count of word <%s> = %s" \
		  %(word, cond_word_cnt)
	print "conditional probabilty of <%s> given <%s> = %s" \
		  %(kgram, word, prob)

	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "2e) test collocation"
	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	ngram = "Subject : vastar" #input

	print ngram_is_collocation(dict_i_to_j_gram_keys, ngram)

	print "~~~~~~~~~~~~~~end~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# N-GRAM-BUILDING-PART starts here
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

def build_i_gram_to_j_gram_keys(corpus, i, j):
	"""
	builds a data structure of nested dictionaries  {0: {0: 0}, 0: {0: 0}, ...}
		out of a PlaintextCorpusReader object containing txt files
	outer key is a k-gram with i <= k <= j
	inner key is the word following th k-gram
	inner value is the count of occurences of n-gram=k-gram+word
	"""
	# tokenize the corpus into list
	corpus_words = corpus.words()

	# data structure with i-gram to j-gram key
	if (ds1):dict_of_igram_to_jgram_keys = {0: {0: 0}}
	if (ds2):dict_of_igram_to_jgram_keys ={0: (0, {0: 0})}

	# k-gram iterator: i <= k <= j
	if (ds1):dict_of_kgrams_keys = {0: {0: 0}}
	if (ds2):dict_of_igram_to_jgram_keys ={0: (0, {0: 0})}

	print "building n-gram data-structure..."
	iter=1
	#iterate k from i to j
	for k in range(i,j+1):

		#build dict with k-gram keys
		dict_of_kgrams_keys = build_k_gram_keys(corpus_words, k)

		#update dict with additional k-gram keys
		dict_of_igram_to_jgram_keys.update(dict_of_kgrams_keys)

		percent_done=iter*int(1/(j+1-i)*100)
		print "%s percent done..." %(percent_done),
		iter+=1

	print "... done"
	#return dict
	return dict_of_igram_to_jgram_keys, corpus_words


def build_k_gram_keys(corpus_words, k):
	"""
	builds a data structure of nested dictionaries  {0: {0: 0}, 0: {0: 0}, ...}
		out of a PlaintextCorpusReader object containing txt files
	outer key is a k-gram with k fixed
	inner key is the word following th k-gram
	inner value is the count of occurences of n-gram=k-gram+word
	"""
	# nr of tokens in corpus
	length=len(corpus_words)

	# data structure
	if (ds1):dict_of_kgram_keys={0:{0:0}}
	if (ds2):dict_of_kgram_keys = {0: (0,{0: 0})}
	if (ds2):tuple_of_next_words_and_k=(0,{0: 0})
	dict_of_next_words={0:0}

	# iterate through all tokens in list
	for i in range(0,length-k):

		# extract the k-gram key as list from the token list
		k_gram_list = corpus_words[i:i+k] #excl. i+k

		# convert the k-gram key as list into a string
		k_gram_string =' '.join(k_gram_list)

		# the word following the k-gram key
		next_word = corpus_words[i+k] #incl. i+k

		# return the nested dictionary with key = k-gram
		if (ds1):dict_of_next_words = dict_of_kgram_keys.get(k_gram_string)
		if (ds2):
			# the nested tuple may be empty
			if dict_of_kgram_keys.get(k_gram_string) is not None:
				dict_of_next_words = dict_of_kgram_keys.get(k_gram_string)[1]
			else:
				dict_of_next_words = None

		# the nested dictionary may be empty (of type None)
		if dict_of_next_words is not None:

			# the dictionary entry with key = next word
			# gets incremented (n-gram counter)
			cnt_ngram = dict_of_next_words.get(next_word,0)
			cnt_ngram = cnt_ngram + 1

			# the nested dictionary gets updated
			dict_of_next_words.update({next_word: cnt_ngram})

			# make a nested tuple
			if (ds2):tuple_of_next_words_and_k = (k, dict_of_next_words)

			# the outer dictionary gets updated
			if (ds1):dict_of_kgram_keys.update({k_gram_string:dict_of_next_words})
			if (ds2):dict_of_kgram_keys.update(
				{k_gram_string: tuple_of_next_words_and_k})
		else:

			# the outer dictionary gets updated for a new k-gram
			if (ds1):dict_of_kgram_keys.update({k_gram_string: {next_word:1}})
			if (ds2):dict_of_kgram_keys.update(
				{k_gram_string: (k, {next_word: 1})})

	#return dictionary
	return dict_of_kgram_keys

def build_dict_test(dict, just_summary):
	"""
	prints data structur sorted by keys
	or
	just a summary with length information
	Data structures:
	1) {k-gram:{word:value}}
	2) {k-gram:(k,{word:value})}
	"""
	print "infos about our data structure"

	if (just_summary==0):

		print "~~~~~~~~~~~~~~~dictionary~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		print dict

		print "~~~~~~~~~~~~~~~key {word: cnt}~~~~~~~~~~~~~~~~~~~~~~~~"
		for key in sorted(dict.keys()):
			print  "%15s\t%15s" % (key, dict[key])

		print "~~~~~~~~~~~~~~~key word cnt~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		for key in sorted(dict.keys()):

			if (ds1):nested_keys=sorted(dict[key].keys())
			if (ds2):nested_keys=sorted(dict[key][1].keys())

			for word in nested_keys:

				if (ds1):print "%15s\t%15s\t%15s" % (
					key, word, dict[key][word])

				if (ds2): print "%15s\t%15s\t%15s" % (
					key, word, dict[key][1][word])

	else:

		nr_of_keys=len(dict.keys())
		sum_up = 0

		for key in dict.keys():

			if (ds1):values = dict[key].values()
			if (ds2): values = dict[key][1].values()

			sum_up=sum_up+sum(values)

		print " nr of keys:", nr_of_keys, "\n nr of k-grams", sum_up

	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"

def print_list(corpus_words):
	"""
	prints a list comma separated
	"""
	print "~~~~~~~~~~~~~~~List~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"

	for word in corpus_words:
		print word,

	print
	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Aufgaben a) bis e)
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# a)
def k_gram_exists(dict, kgram):
	"""
	function to check whether an ngram exists as a key in the main dict
	"""
	if kgram in dict.keys():
		return True
	else:
		return False


# b)
def print_n_grams(dict, kgram):
	"""
	function to build a list of all possible ngram-completions
		given a k-gram (n-grams = k-gram + words)
	Example:
		corpus = "The car is green. The house is big"
		complete_ngram(dict, 'is')
		>>> [u'is green', u'is big']
	"""
	#checks whether the k-gram key exists
	if k_gram_exists(dict, kgram):

		# to store n-grams = k-gram + words
		ngram_list = []

		# iterate through the words of the nested dictionary
		# 1){k-gram:{word:value}}
		# 2){k-gram:(k,{word:value})}
		if (ds1):dict_nested = dict[kgram].keys()
		if (ds2):dict_nested = dict[kgram][1].keys()

		for word in dict_nested:

			# build ngram and add it to the ngram_list
			new_ngram = kgram + " " + word

			# append n-gram to list
			ngram_list.append(new_ngram)
			
		# returns the list of n-grams
		return ngram_list

	else:

		print "please enter a k-gram that exsists in our data"


# c)
def unconditional_prob_of_k_gram(dict, kgram, kgrams_cnt):
	"""
	function to compute the unconditional probability of a k-gram
	total count of k-grams equals corpus length minus k
	"""
	# checks whether the k-gram key exists
	if k_gram_exists(dict, kgram):

		# frequency of the specific ngram as a sum of all
		# frequencies of following words
		# 1){k-gram:{word:value}}
		# 2){k-gram:(k,{word:value})}
		if (ds1):kgram_cnt = sum(dict[kgram].values())
		if (ds2):kgram_cnt = sum(dict[kgram][1].values())
		
		# return unconditional probability of k-gram
		return (kgram_cnt / kgrams_cnt), kgram_cnt

	else:

		print "please enter a ngram that exsists in our data"


# d)
def conditional_prob_of_word_given_k_gram(dict, kgram, word):
	"""
	function to compute the conditional probability of an n-gram
		given the k-gram
	"""
	# checks whether the k-gram key exists
	if k_gram_exists(dict, kgram):

		# occurences of k-gram
		# 1){k-gram:{word:value}}
		# 2){k-gram:(k,{word:value})}
		if (ds1):k_gram_cnt = sum(dict[kgram].values())
		if (ds2): k_gram_cnt = sum(dict[kgram][1].values())

		# occurences of word given k-gram
		if (ds1):cond_word_cnt = dict[kgram][word]
		if (ds2): cond_word_cnt = dict[kgram][1][word]

		return (cond_word_cnt / k_gram_cnt), cond_word_cnt, k_gram_cnt

	else:
		print "please enter a ngram that exsists in our data"

# e)
def ngram_is_collocation(dict, ngram):
	"""
	function applying the bigram_collocation-check to tri-grams.

	reasoning behind it: if the first two words of a trigram aren't
	a collocation, the trigram won't be a collocation either
	"""
	len_ngram = len(ngram.split())

	if len_ngram < 3:
	
		if bigram_is_collocation(dict, ngram):
			return "'%s' is a collocation" % ngram
		else:
			return "'%s' is not a collocation" % ngram
	
	elif len_ngram == 3:
	
		if trigram_is_collocation(dict, ngram):
			return "'%s' is a collocation" % ngram
		else:
			return "'%s' is not a collocation" % ngram
			
	else:
		return "Little Britain: computer says nooo.\n " \
			   "Monty Python: traceback"


def bigram_is_collocation(dict, bigram):
	"""
	decides whether two words tend to occur together more often than alone.
	only checks the result for bigrams 
	"""
	# checks whether the k-gram key exists
	if k_gram_exists(dict, bigram):
	
		try:
			first_word = bigram.split()[-2]
			second_word = bigram.split()[-1]					
		except IndexError:
			print "please enter a bigram"
			exit();

		if (ds1):cnt_bigram = dict[first_word][second_word]
		if (ds2):cnt_bigram = dict[first_word][1][second_word]
		
		cond_prob = conditional_prob_of_word_given_k_gram(
			dict, first_word, second_word)[0]
		
		## defining the thresholds for becoming a collocation
		# the conditional probability of the first word given the
		# second should be more than 0.5 (this value can be changed)
		cond_prob_threshold = 0.5
		print "cond_prob_threshold:", cond_prob_threshold

		# the collocation should occur more than 5 times in our
		# data to count as collocation (this can be changed as well)
		absolute_frequency_threshold = 5
		print "absolute_frequency_threshold:", absolute_frequency_threshold 

		if cnt_bigram > absolute_frequency_threshold and \
						cond_prob > cond_prob_threshold:
			True
		else:
			False

	else:
		print "please enter a ngram that exsists in our data"




def trigram_is_collocation(dict, ngram):
	"""
	decides whether two words tend to occur together more often than alone.
	only checks the result for bigrams
	"""
	# checks whether the k-gram key exists
	if k_gram_exists(dict, ngram):

		pre_gram = " ".join(ngram.split()[:2])

		if bigram_is_collocation(dict, pre_gram):
			return bigram_is_collocation(dict, ngram)
		else:
			return False

	else:
		print "please enter a ngram that exsists in our data"


#Main
if __name__ == "__main__":
	main()