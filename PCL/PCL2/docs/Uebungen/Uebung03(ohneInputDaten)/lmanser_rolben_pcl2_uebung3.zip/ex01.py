#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# PCL-I: Uebung 03 - Aufgabe 1, FS16

# Autoren:
# c(Student, Martikelnummer) -> {'Roland Benz'	: '97-923-163',
#								 'Linus Manser' : '13-791-132'}
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Aufruf/Import des Programms:
# python ex01.py
# import ex01.py
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# generate corpora with nltk PlaintextCorpusReader
#=================================================
import nltk
from nltk.corpus.reader.plaintext import PlaintextCorpusReader as PCR
import os


# generate corpus, encoding is utf-8 by default
def own_corpus_reader():

	# get current working directory
	current_dir = os.getcwd()

	corpusdir = current_dir + "/Enron/enron_subset"
	test_set_dir = current_dir + "/Enron/test_set"
	
	#read all .txt files in directory
	ham_spam_corpus = PCR(corpusdir, ".*\.txt")
	spam_corpus = PCR(corpusdir, ".*spam\.txt")
	ham_corpus = PCR(corpusdir, ".*ham\.txt")
	test_corpus = PCR(test_set_dir, ".*\.txt")

    #define here other variables
    #...words, nr of tokens and so on
    #or even better make a class with instance variables

    #return all variables separated by comma
	return ham_spam_corpus, ham_corpus, spam_corpus, test_corpus
    
#not run when file imported with: import ex01
if __name__ == "__main__":

	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "corpora generated"
	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"


