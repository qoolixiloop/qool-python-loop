#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# PCL-I: Uebung 03 - Aufgabe 3, FS16

# Autoren:
# c(Student, Martikelnummer) -> {'Roland Benz'	: '97-923-163',
#								 'Linus Manser' : '13-791-132'}
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
from __future__ import division
#used corpora as data input
import ex01
import ex02

#used functionality for ML
import operator
import random
import nltk
from collections import Counter

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Main
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# set the flags for debug info
debug=0


def main():
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	print "1~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "loading corpora ...\n"
	ham_spam_corpus, ham_corpus, spam_corpus, test_corpus = \
		ex01.own_corpus_reader()

	# ham spam corpus
	nr_of_docs_loaded = len(ham_spam_corpus.fileids())
	print "nr of documents loaded: ", nr_of_docs_loaded

	# ham corpus
	nr_of_hams_loaded = len(ham_corpus.fileids())
	print "nr of hams loaded: ", nr_of_hams_loaded

	# spam corpus
	nr_of_spams_loaded = len(spam_corpus.fileids())
	print "nr of spams loaded: ", nr_of_spams_loaded

	# test corpus
	nr_of_tests_loaded = len(test_corpus.fileids())
	print "nr of tests loaded: ", nr_of_tests_loaded
	

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	print "2~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "converting corpora into a list of tuples\n"
	# -------------------------------------
	#[([text-tokens],category=pos/neg),"
	#([text-tokens],category=pos/neg),...]

	# concept: used to generate the features list and train the NBC
	documents_as_list_of_words_and_label = \
		[build_document_tuples(ham_spam_corpus, fileid)
		for fileid in ham_spam_corpus.fileids()]

	# concept: used as completey unknown test set
	# used at the end of the development process
	# (ensures an unbiased test result)
	test_set_as_list_of_words_and_label = \
		[build_document_tuples(test_corpus, fileid)
		 for fileid in test_corpus.fileids()[500:]]

	# concept: used as development test set to
	# iteratively improve features
	# (becomes biased after each iteration of improving
	# feature extraction function)
	errorsampling_set_as_list_of_words_and_label_with_id = \
		[(build_document_tuples(test_corpus, fileid), fileid)
		for fileid in test_corpus.fileids()[:500]]
			 

	# randomly shuffle the words
	# --------------------------
	random.shuffle(documents_as_list_of_words_and_label)
	random.shuffle(test_set_as_list_of_words_and_label)
	random.shuffle(errorsampling_set_as_list_of_words_and_label_with_id)


	if(debug):print documents_as_list_of_words_and_label

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	print "3~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "making a features list containing words and n-grams ...\n"
	# -------------------------------------------------

	# tokenize the corpus into list
	corpus_words = ham_spam_corpus.words()
	ham_words = ham_corpus.words()
	spam_words = spam_corpus.words()

	print "nr of token in corpus: ", len(corpus_words)
	print "nr of token in ham: ", len(ham_words)
	print "nr of token in spam: ", len(spam_words)

	# the parameter is part of a heuristic:
	# has the effect of a stop list (caps the occurences of
	# words from above and floors the DELTAS of occurences
	# of words from below beween hams and spams)
	parameter = random.randrange(
		int(nr_of_docs_loaded*0.1), int(nr_of_docs_loaded*0.2))

	# build most informative n-grams
	# (unigrams, bigrams, trigrams)
	sorted_ngram_list, sorted_list_of_ngram_tuples, ngram_dict = \
		most_informative_n_grams_dict(
		corpus_words, ham_words, spam_words, parameter)

	print "nr of different words extracted: ", len(sorted_ngram_list)
	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "list of most informative words in the corpus:\n" \
		  "(only a subset printed)\n", sorted_ngram_list[:100]
	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "list of most informative words in the corpus:\n" \
		  "inclusive DELTA = difference of occurence in hams and spams" \
		  "(only a subset printed)\n", sorted_list_of_ngram_tuples[:100]

	# limit the feature dimensions
	# parameter is a heuristic to limit the number of dimensions
	parameter = min(nr_of_docs_loaded, 700)
	word_features_list = sorted_ngram_list[:parameter]

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	print "4~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "calling feature extractor function ...\n"
	# call feature extractor function that checks
	# whether each of the words in the word_features_list
	# is present in the given documents"
	# ---------------------------------------------------
	#[({text-tokens of document 1:True/False},category=ham/spam),
	#({text-tokens of document 2:True/False},category=ham/spam),...]

	#this is used in step 5 as training_set and development_test_set
	#(notice: the same documents were used to make the features list
	# in step 3)
	documents_as_features_and_label = \
		[(document_features(list_of_words, word_features_list),
		  doc_label)
        for (list_of_words, doc_label) in
		 documents_as_list_of_words_and_label]

	#this is used in step 6 as test_set
	#(completely unknown documents to NBC)
	test_set_as_features_and_label = \
		[(document_features(list_of_words, word_features_list),
		  doc_label)
		 for (list_of_words, doc_label) in
		 test_set_as_list_of_words_and_label]

	# task 3a)
	# empty feature set:
	# document_features_baseline returns an empty dictionary
	# (imput arguments not needed)
	documents_as_empty_features_and_label = \
		[(document_features_baseline(list_of_words, word_features_list),
		  doc_label)
		 for (list_of_words, doc_label) in
		 documents_as_list_of_words_and_label]


	if (debug):print documents_as_features_and_label

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	print "5~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "training classifier ...\n"
	# ------------------
	# cut the set into 90% training and 10% development test set
	cut = (int)(nr_of_docs_loaded*0.9)
	print "divide nr of documents loaded into\ntraining examples: " \
		  "%s \ntest examples: %s" \
		  %(cut, nr_of_docs_loaded-cut)

	training_set = documents_as_features_and_label[:cut]
	development_test_set = documents_as_features_and_label[cut:]

	# NBC training
	classifier = nltk.NaiveBayesClassifier.train(training_set)

	# task 3a)
	# train NBC with empty feature set
	classifier_baseline = nltk.NaiveBayesClassifier.train\
		(documents_as_empty_features_and_label)

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	print "6~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	# check accuracy
	# since the development_test_set and the generation of
	# the features list in step 3 used the same documents
	# the accuracy is biased (higher 93%)
	print "accuracy with development_test_set:"
	print nltk.classify.accuracy(
		classifier, development_test_set)

	# since the documents in the test set are completely unknown
	# to the NBC the accuracy is unbiased (lower 85%)
	print "accuracy with test_set:"
	print nltk.classify.accuracy(
		classifier, test_set_as_features_and_label)

	# task 3a)
	# accuracy of NBC trained with empty feature set
	# (always says spam if more spam documents are used to train
	# the NBC and vice versa.)
	print "accuracy with empty feature set (baseline):"
	print nltk.classify.accuracy(
		classifier_baseline, test_set_as_features_and_label)

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	print "7~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	# check most informative features
	# result of a principal component analysis
	print "True means Ham\nFalse means Spam"
	classifier.show_most_informative_features(5)

	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	print "8~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	# Application of the trained NBC
	# on the iteratively used set
	# (becomes biased after each iteration of improving feature
	# extraction function)
 	print "Error-list to help specify new features \n" \
		  "(dev_test-section in the nltkbook):\n"
 	
	# contains the wrong classifications
	errors = []

	# iterate through the set by extracting ((mail,label), id)
	for ((mail,label), id) in \
			errorsampling_set_as_list_of_words_and_label_with_id:

		# appy the trained NCB on each document in the set
		guess = classifier.classify(
			document_features(mail, word_features_list))

		# checks whether the guess of NBC was correct
		if guess != label:

			#renaming of the output (0/1 -> spam/ham)
			if guess == 0:
				guess = "spam"
			else:
				guess = "ham"
				
			if label == 0:
				label = "spam"
			else:
				label = "ham"
			errors.append( (label, guess, id) )

	# output of all wrong classifications
	for (label, guess, id) in sorted(errors):
		print "correct=%-5s guess=%-5s mail_ID=%s" % (label, guess, id)

	# output of summary informations
	print "\nnumber of mails: %i \nnumber of errors: %i" \
		  "\nerror-rate: %f"  % \
	(len(errorsampling_set_as_list_of_words_and_label_with_id),
	 len(errors),
	 (len(errors)/len(errorsampling_set_as_list_of_words_and_label_with_id)))
	 
	print "\nAntwort zur Frage 3a):\nGegeben man nimmt die Baseline-funktion," \
	"welche keine features deklariert, waehlt der Klassifikator den im Trainingsset am haeufigsten vorkommende Tag " \
	"fuer alle Mails.\n"

	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "End of Script"
	print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"


def most_informative_n_grams_dict(corpus_words, ham_words, spam_words,
								  parameter):
	"""
	returns a dict of most informative n-grams
	parameter servers as a frequency cap
	"""
	# dict to store and return n-grams
	ngram_dict={}

	#calculate n-grams
	#unigram_dict = nltk.FreqDist(w.lower() for w in corpus_words)

	print "building n-grams...",
	corpus_unigram_dict = Counter(corpus_words)
	corpus_bigram_dict = build_n_gram_dict(corpus_words, 2)
	corpus_trigram_dict = build_n_gram_dict(corpus_words, 3)
	print "40% done...",

	ham_unigram_dict = Counter(ham_words)
	ham_bigram_dict = build_n_gram_dict(ham_words, 2)
	ham_trigram_dict = build_n_gram_dict(ham_words, 3)
	print "70% done...",

	spam_unigram_dict = Counter(spam_words)
	spam_bigram_dict = build_n_gram_dict(spam_words, 2)
	spam_trigram_dict = build_n_gram_dict(spam_words, 3)
	print "99% done..."

	# only those n-grams with a certain DELTA frequency
	# unigrams
	for key in corpus_unigram_dict:
		# remove very frequent words
		corpus_cnt = corpus_unigram_dict.get(key,0)
		if corpus_cnt < parameter:
			ham_cnt = ham_unigram_dict.get(key, 0)
			spam_cnt = spam_unigram_dict.get(key, 0)
			# delta should be resonably high
			DELTA = abs(ham_cnt - spam_cnt)
			if DELTA > parameter*0.3:
				ngram_dict.update({key: DELTA})


	# bigrams
	for key in corpus_bigram_dict:
		# remove very frequent words
		corpus_cnt = corpus_bigram_dict.get(key,0)
		if corpus_cnt < parameter:
			ham_cnt = ham_bigram_dict.get(key, 0)
			spam_cnt = spam_bigram_dict.get(key, 0)
			# delta should be resonably high
			DELTA = abs(ham_cnt - spam_cnt)
			if DELTA > parameter*0.2:
				ngram_dict.update({key:DELTA})


	# trigrams
	for key in corpus_trigram_dict:
		# remove very frequent words
		corpus_cnt = corpus_trigram_dict.get(key,0)
		if corpus_cnt < parameter:
			ham_cnt = ham_trigram_dict.get(key, 0)
			spam_cnt = spam_trigram_dict.get(key, 0)
			# delta should be resonably high
			DELTA = abs(ham_cnt - spam_cnt)
			if DELTA > parameter*0.1:
				ngram_dict.update({key:DELTA})

	# reverse sorted list of n-gram tuples (n-gram, DELTA)
	sorted_list_of_ngram_tuples = []
	for key in sorted(ngram_dict.keys(), key=ngram_dict.get, reverse=True):
		ngram_tuple=(key, ngram_dict[key])
		sorted_list_of_ngram_tuples.append(ngram_tuple)

	# reverse sorted list of n-grams
	sorted_ngram_list = sorted(ngram_dict.keys(), key=ngram_dict.get, reverse=True)

	print "... done"
	# return
	return sorted_ngram_list, sorted_list_of_ngram_tuples, ngram_dict

def build_n_gram_dict(corpus_words, n):
	"""
	returns a dict of n-grams
	"""
	# nr of tokens in corpus
	length=len(corpus_words)

	# data structure
	dict_of_ngrams={}

	# iterate through all tokens in corpus list
	for i in range(0,length-n):

		# extract the n-gram as list from the token list
		n_gram_list = corpus_words[i:i+n] #excl. i+n

		# convert the k-gram as list into a string
		n_gram_string =' '.join(n_gram_list)
		n_gram_string = n_gram_string.lower()

		# update the dict of n-grams
		# the dictionary entry with key = next word
		# gets incremented (n-gram counter)
		cnt_ngram = dict_of_ngrams.get(n_gram_string, 0)
		cnt_ngram = cnt_ngram + 1
		dict_of_ngrams.update({n_gram_string:cnt_ngram})

	#return dictionary
	return dict_of_ngrams


def build_document_tuples(corpus, fileid):
	"""
	input: FileID
	output:	builds a list of tokenized emails in a tuple together with the spam/ham label
	ham: True
	spam: False
	"""
	#tokenize document with given fileid
	list_of_words = corpus.words(fileid)

	#check whether the fileid contains the text <ham.txt>
	if ".ham.txt" in fileid:
		return (list_of_words, True)
	else:
		return (list_of_words, False)

#feature extractor functions
def document_features(list_of_words, word_features_list):
    """
    A feature extractor for document classification, whose features indicate whether or not
    individual words are present in a given document.
    """
    #convert list of words to set
    set_of_words = set(list_of_words)

	#calculate k-gram

    #dictionary to store the document features
    dict_of_features = {}

	#set flag True/False depending on whether a word
	#in the word_features_list is present in the document
    for word in word_features_list:

        #features[key]=value, key=word, value=True/False
        dict_of_features['contains(%s)' % word] = (word in set_of_words)

    #returns a dictionary
    return dict_of_features
   
# empty dict to comply with the requirements of the classifier 
def document_features_baseline(list_of_words, word_features_list):
	return {}
    

if __name__ == "__main__":
	main()
