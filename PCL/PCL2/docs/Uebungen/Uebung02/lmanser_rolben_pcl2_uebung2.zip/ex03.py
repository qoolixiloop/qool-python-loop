#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# PCL-II: Uebung 02 - Aufgabe 3, FS16

# Autoren:
# c(Student, Martikelnummer) -> 	{'Roland Benz'			: '97-923-163',
#									 'Linus Manser' 		: '13-791-132'}

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## necessary import to parse an xml-file 
from lxml import etree


## dictionnare with questions with corresponding "XPath-Translations"
questions = {
"Welche Pflanzen haben bei der Eigenschaft 'Zone' einen Wert von 5?":"/PLANTS/PLANT[@zone = '5']",
"Wieviel würde es kosten, wenn man eines jeder Pflanze kaufen würde?":"sum(/PLANTS/PLANT/PRICE/text())",
"Welche Pflanzen brauchen Schatten, 'Shade'? Nenne ihre botanischen Namen.":"/PLANTS/PLANT[./LIGHT/text() = 'Shade']/BOTANICAL[not(. = ../following::BOTANICAL)]/text()",
"Wieviele Pflanzen gibt es insgesamt?":"count(/PLANTS/PLANT)"
}

## parsing of 'plants.xml' with etree.parse()
tree = etree.parse("plants.xml")


def display_info(question):
	"""
	INPUT: Question -> XPath-Expression
	OUTPUT: displayed output (depending on Type of the output)
	"""
	# extract correct xpath-expression for the corresponding question
	xpath_expression = questions[question]
	
	# run the xpath-expression to search in 'tree' (parsed xml-file)
	ans = tree.xpath(xpath_expression)
	
	# display xpath-expression
	print "XPath-Expression: %s\n" % xpath_expression
	
	try:
		for i in ans:
			try:
				print etree.tostring(i)
			# Lists can't be serialized (lxml TypeError)
			except TypeError:
				print i
	# for non-iterable datatypes
	except TypeError:
		try:
			print etree.tostring(ans)
		except TypeError:
			print ans


		
if __name__ == "__main__":
	
	# to ensure correct enumberation of question
	q_counter = 1
	
	for question in questions:		
		print "\n%i)" % q_counter,
		print question		
		display_info(question)
		
		# increment q_counter by 1
		q_counter += 1








