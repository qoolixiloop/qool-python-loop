#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# PCL-I: Uebung 06 - Aufgabe 1, FS16
#
# Autoren:
# c(Student, Martikelnummer) -> {'Roland Benz'	: '97-923-163',
#								 'Linus Manser' : '13-791-132'}
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Reflexion/Feedback
# a) Ich habe ein neues Modul von nltk kennengelernt, welches mir 
#    erlaubt mit kontextfreien Grammatiken (mot oder ohne Wahr-
#    scheinlichkeiten) Syntaxbäume zu generieren und sie auf 
#    verschiedene Arten auszugeben. Zusätzlich konnte ich mit
#    der ersten auf Aufgabe den CYK-Algorithmus "visualisieren" 
#    und ihn somit besser kennenlernen. 
#    
# b) 6 Stunden 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#imports
import nltk
import argparse
import sys
import os

#debug flag - set to 1 if in debug mode
DEBUG = 0

def build_tree_collection(parser, sent):
    """
    function that compiles all possible or the most probable tree(s)
    depending on which parser you use

    input:  desired parser (ChartParser, ViterbiParser, ...)
            a sentence which needs to be parsed
    output: ChartParser -> all possible trees
            ViterbiParser -> most probable tree
            as a tuple together with the corresponding sentence
    """
    # list of all possible trees generated from one sentence
    tree_collection = []

    if DEBUG: print "\ninformation for sent:", sent
    
    for tree in parser.parse(sent):
        if DEBUG: print "type of tree: ", type(tree)
        tree_collection.append(tree)

    if DEBUG: print "tree collection: ", tree_collection

    return (sent, tree_collection)

def write_out_to_tex(trees, out_file):
    """
    all-in-one function to convert all tree from all sentences into a .tex-file
    combines static content (prolog, epilog, subsections, ...) with the syntax trees

    input:  all trees from all sentences
            output file (given as an argument)
    output: TeX-file written to the output file (pref: *.tex)
    """

    # hard-coded text as static content for the .tex-file
    br = "\n" #linebreak

    prolog = r"\documentclass[12pt]{article}" + br + \
    r"\usepackage{tikz}" + br + \
    r"\usepackage{tikz-qtree}" + br + \
    r"\title{Programiertechniken in der Computerlinguistik II: Assignment 6}" + br + \
    r"\author{Linus Manser (13-791-132), Roland Benz (97-923-163)}" + br + \
    r"\date{Abgabe: 2016/06/08}" + br + br + \
    r"\begin{document}" + br + br + \
    r"\maketitle" + br + \
    r"\section{Syntax trees}" + br

    content = ""

    for tree_collection in trees:
        # extracting the different data from the tuple
        (sent, tree_collection) = tree_collection
        sent = " ".join(sent)
        content += r"\subsection{" + sent + r"}" +\
            br + r"\begin{enumerate}" + br
        
        for tree in tree_collection:
            # http://www.nltk.org/howto/tree.html
            # compiling latex content which goes in-between (actual trees)
            content += r"\item\begin{center}" + "\n%s\n" % tree.pformat_latex_qtree() +\
                 br + r"\end{center}" + br
 
        content += r"\end{enumerate}" + br
            
    # marking the end of the latex-file
    epilog = r"\end{document}"
    # concatenate the whole content (incl. static)
    whole_content = prolog + content + epilog
    # write the whole content to the given output file
    out_file.write(whole_content)

    if DEBUG: print "DONE: out_file written (see below)\n", whole_content


def main():
    # setting up the arguments with argparse
    argparser = argparse.ArgumentParser()
    argparser.add_argument('-o','--out', type=argparse.FileType('w'),\
        metavar='FILE', help='output file')
    argparser.add_argument('-g','--grammar', type=argparse.FileType('r'),\
        metavar='FILE', help='grammar file')
    argparser.add_argument('-s','--sents', type=argparse.FileType('r'), \
        default=sys.stdin, metavar='FILE', help='sentence file')
    args = argparser.parse_args()
    
    # try to form a string from the data of the grammar file
    try:
        grammar_string = "".join(args.grammar)
    # if no grammar is given, exit the script
    # (assuming that nobody wants to write the same grammar over and over again)
    except TypeError:
        print "try:\t$ python aufgabe02.py -g [grammar.txt] -s [sentence.txt] -o "\
        "[texfile.tex]\n\t(where '-s' and '-o' are optional arguments)"
        exit()

    parser_decision = 0
    # parsing grammar from string
    try:
        grammar = nltk.CFG.fromstring(grammar_string)
    except ValueError:
        # if the grammar contains probabilites, take the PCFG-method 
        # (and later use the ViterbiParser)
        grammar = nltk.PCFG.fromstring(grammar_string)
        parser_decision = 1

    # instanciating the parser (ChartParser)
    # depending on the grammar, choose one of the Parsers (ChartParser / ViterbiParser)
    if parser_decision == 0:
        parser = nltk.ChartParser(grammar)
    elif parser_decision == 1:
        parser = nltk.ViterbiParser(grammar)

    # collecting input form the given file (or: stdin by default)
    sent_file = args.sents

    # assuming that each line corresponds to a sentence
    out_file = args.out

    # list containing all possible trees for every sentence
    all_trees_from_all_sentences = []

    # parse all sentences inside the sentence file
    for sent in sent_file:
        if DEBUG: print "\nparsing sentence: ", sent, type(sent)
        sent = sent.split()
        # parsing the sentence with the given parser
        # and appending it to the bigger list (all_trees_from_all_sentences)
        all_trees_from_all_sentences.append(build_tree_collection(parser, sent))
        if DEBUG: print "parsing of sentence: ", sent, " -> done"

    # printing the trees onto the command line with pretty print
    for tree_collection in all_trees_from_all_sentences:
        # extracting the data from the given tuple
        (sent, tree_collection) = tree_collection
        sent = " ".join(sent)
        print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
        print "sentence: '%s'" % sent
        v_enum = 1
        
        for tree in tree_collection:
            print "version %i" % v_enum
            # http://www.nltk.org/howto/tree.html
            tree.pretty_print(unicodelines=True, nodedist=4)
            v_enum += 1
            
    # compiling the .tex file
    if out_file: 
        write_out_to_tex(all_trees_from_all_sentences, out_file)
    else:
        print "(no output file selected. write '-o outfile.tex' as an argument when " \
            "running the script if you want to generate a .tex file)"
    

if __name__ == "__main__":
	main()