#!/usr/bin/env python
# -*- coding: utf-8 -*-
#PCL I, Übung 5, HS15
#Aufgabe 3.1 c)
#Autor: Irene
#Matrikel-Nr.: *


from nltk.book import *

def task3_1(text):
	result = []
	for word in set(text):
		if len(word) >= 4 and word[-3:] == 'ing':
			result.append(word.lower())
	return sorted(result)


def main():
	list = task3_1(text6)
	print 'The function evaluates to a list of',len(list),'elements.'
	list2 = sorted([word.lower() for word in set(text6) if len(word) >= 4 and word[-3:] == 'ing'])
	print 'The list comprehension produces a list of',len(list2),'elements.'
	print list == list2


if __name__ == '__main__':
	main()
