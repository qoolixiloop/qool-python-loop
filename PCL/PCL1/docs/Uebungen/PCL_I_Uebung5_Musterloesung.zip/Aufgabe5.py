#!/usr/bin/env python
# -*- coding: utf-8 -*-
#PCL I, Übung 5, HS15
#Aufgabe 5
#Autor: Irene
#Matrikel-Nr.: *

import operator, sys
from nltk.corpus import webtext

def wordsbylength(text,length):
	#Alternative: return [word.lower() for word in text if len(word) == length]
	out = []
	for word in text:
		if len(word) == length:
			out.append(word.lower())
	return out

def wordswithletter(text,letter):
	#Alternative: return [word.lower() for word in text if word[0] == letter]
	out = []
	for word in text:
		if word[0] == letter:
			out.append(word.lower())
	return out

def wordsfrequency(list):
	#Erstellt Dictionary mit Worthäufigkeit der Wörter in list
	dict = {}
	for item in list:
		if item in dict:
			dict[item] += 1
		else:
			dict[item] = 1
	return dict

def printresult(dict):
	#sortiert dict und gibt key-value paar mit grösstem value aus
	if dict:
		mostfreq = sorted(dict.items(), key = operator.itemgetter(1))[-1]
	else:
		mostfreq = ('None',0)
	print mostfreq[0], ":", mostfreq[1]

def main():
	text = webtext.words('grail.txt')

	#Kommandozeilenargumente
	length = int(sys.argv[1])
	letter = sys.argv[2]

	#Listen der Wörter, welche betrachtet werden sollen
	lenlist = wordsbylength(text,length)
	letterlist = wordswithletter(text,letter)
	lenletterlist = wordswithletter(lenlist,letter)

	#Ausgabe
	print "\nHäufigstes Wort mit",length,"Buchstaben:"
	printresult(wordsfrequency(lenlist))
	print "Häufigstes Wort mit Anfangsbuchstabe",letter,":"
	printresult(wordsfrequency(letterlist))
	print "Häufigstes Wort mit",length,"Buchstaben und Anfangsbuchstabe",letter,":"
	printresult(wordsfrequency(lenletterlist))

if __name__ == "__main__":
	main()