#!/usr/bin/env python
# -*- coding: utf-8 -*-
#PCL I, Übung 5, HS15
#Aufgabe 6
#Autor: Irene
#Matrikel-Nr.: *

from nltk.corpus import brown

def freq(cat,word):
	return brown.words(categories=cat).count(word)

def conditionalfreq(cats,words):
	dict = {}
	for c in cats:
		dict[c] = {word:freq(c,word) for word in words}
	return dict

def relmax(dict, word):
	max = 0
	cat = ''
	for key in dict:
		anteil = float(dict[key][word])/len(brown.words(categories=key))
		if anteil >= max:
			max = anteil
			cat = key
	print "Kategorie mit grösstem Anteil ist:"
	print cat

def relmin(dict, word):
	min = 1
	cat = ''
	for key in dict:
		anteil = float(dict[key][word])/len(brown.words(categories=key))
		if anteil <= min:
			min = anteil
			cat = key
	print "Kategorie mit kleinstem Anteil ist:"
	print cat,"\n"

def main():
	words = [u'money',u'duty',u'love',u'heart']
	cats = [u'romance',u'religion',u'science_fiction',u'government',u'humor']
	#cats = brown.categories()
	dict = conditionalfreq(cats,words)
	for w in words:
		print "[",w,"]"
		relmax(dict,w)
		relmin(dict,w)

if __name__ == "__main__":
	main()
