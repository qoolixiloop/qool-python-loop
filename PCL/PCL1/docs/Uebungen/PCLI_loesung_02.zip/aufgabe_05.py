#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# PCL1-Ü2-Aufgabe 5
# Musterlösung von Raphael Balimann (raphael.balimann@uzh.ch) - HS 2015
#

usrinput = ''

# WHILE-Schleife, welche bis zum Abbruch fortsetzt
while (usrinput != 'q'):

	# Überprüfung, ob noch mehr Input folgt
	usrinput = raw_input("Bitte gebe ein deutsches Wort ein, Abbruch mit 'q': ")
	
	# Fallunterscheidung nach Merkmalen der Eingabe
	# Letzte Zeichen sind 'en'
	if (usrinput[-2:] == 'en'):
	
			# Letzte Zeichen sind 'sten'
		if (usrinput[-4:] == 'sten'):
			print "Das eingegebene Wort ist wahrscheinlich ein Adjektiv im Superlativ."
		
		else:
			print "Das eingegebene Wort ist wahrscheinlich ein Verb."
		
	# Letztes Zeichen ist 't'
	elif (usrinput[-1] == 't'):
		print "Das eingegebene Wort ist wahrscheinlich ein Verb."
		
	# Letzte Zeichen sind 'te'
	elif (usrinput[-2:] == 'te'):
		print "Das eingegebene Wort ist wahrscheinlich ein Verb."

	# Letzte Zeichen sind 'er'
	elif (usrinput[-2:] == 'er'):
		print "Das eingegebene Wort ist wahrscheinlich ein Nomen."

	
	# Wenn nichts erkannt wurde	
	else:
		print "Das eingegebene Wort wurde nicht erkannt."

# Abschlussmeldung
print "Auf Wiedersehen !"