#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# PCL1-Ü2-Aufgabe 4
# Musterlösung von Raphael Balimann (raphael.balimann@uzh.ch) - HS 2015
#

# Endlose WHILE-Schleife, welche den Nutzer immer wieder nach neuen Wörtern fragt
while (True):

	usrinput = raw_input("Gebe ein neues Wort ein: ")
	
	if (len(usrinput) >= 5):
		print usrinput[2:5]
	
	else:
		print "Das Wort ist nicht lang genug!"
		
# Das Problem mit einer endlosen Schleife ist, 
# dass ein Benutzer sie nicht ordentlich beenden kann.
#
# Zudem müssen Nutzereingaben immer geprüft werden, 
# weil sonst könnten sich Indexfehler ergeben.