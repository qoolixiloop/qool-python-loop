#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# PCL1-Ü2-Aufgabe 3
# Musterlösung von Raphael Balimann (raphael.balimann@uzh.ch) - HS 2015
#

# Eingaben durch Nutzer
a =  raw_input("Bitte geben sie a ein : ")
b =  raw_input("Bitte geben sie b ein : ")
c =  raw_input("Bitte geben sie c ein : ")

# Umwandlung in Fliesskommazahlen
# Fliesskommazahlen erfassen immer eine bestimmte Zahl von Nachkommastellen, 
# und könen daher teilweise ähnlich aber immer noch unterschiedlich sein.
a = float(a)
b = float(b)
c = float(c)

# Umwandlung in ganze Zahlen (auskommentiert)
# Die Umwandlung in ganze Zahlen erfolgt durch Abrunden auf die nächste ganze Zahel, 
# daher können sich die Zahlen wesentlich verzerren, insbesondere wenn mehrere Zahlen involviert sind.
# a = int(a)
# b = int(b)
# c = int(c)

# Erstellung von x
x = (a + b + 3)/c

# Erstellung von y
y = (b - a**b)/x

# Ausgabe der beiden Resultate
print "x hat den Wert " + str(x)
print "y hat den Wert " + str(y)