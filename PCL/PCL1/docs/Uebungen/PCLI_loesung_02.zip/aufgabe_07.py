#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# PCL1-Ü2-Aufgabe 7
# beispielhafte Musterlösung von Raphael Balimann (raphael.balimann@uzh.ch) - HS 2015
#

from time import sleep # Optionale Verzögerung der Ausgabe

# Eingabe von Nutzer
usrinput = raw_input("Bitte gebe ein (langes) Wort ein: ")
length = len(usrinput)
continuation = True
local_max = 1

# WHILE-Schleife, welche 
while (continuation):

	while (local_max < length):
		print usrinput[:local_max]
		local_max += 1
		sleep(0.5) # Verzögerung der Ausgabe
			
	if (local_max == length):
		print usrinput
		local_max -= 1
		
	while (local_max > 0):
		print usrinput[:local_max]
		local_max -= 1
		sleep(0.25) # Verzögerung der Ausgabe


	# Eingabe, ob der Nutzer noch weiterfahren will, 
	# wenn "nein" eingegeben wurde, wird der Boolean-Wert continuation auf 'False' gesetzt
	decision = raw_input("Nochmals (ja/nein)? ")
	
	if (decision == 'nein'):
		continuation = False