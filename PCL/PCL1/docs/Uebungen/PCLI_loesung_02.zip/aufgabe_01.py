#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# PCL1-Ü2-Aufgabe 1
# Musterlösung von Raphael Balimann (raphael.balimann@uzh.ch) - HS 2015
#

# eine Variable neu definieren
a = input("Gebe eine Nummer ein: ")

# eine Unterscheidung mit IF
if (a == 42):
	print "Du hast 42 eingegeben!"

# Variable definieren und ausgeben
a = 42
print a


# eine Schleife, welche in Schritten von 2 bis 50 zählt
while (a < 50):

	a += 2
	print a

# Ausstieg mit exit()
exit()