#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# PCL1-Ü2-Aufgabe 2
# Musterlösung von Raphael Balimann (raphael.balimann@uzh.ch) - HS 2015
#

# Eingabe der Namen vom Nutzer, getrennt in Vor- und Nachname
last_name = raw_input('Willkommen, was ist ihr Nachname? ')
first_name = raw_input('Was ist denn ihr Vorname? ')

# Ausgabe der Begrüssung mithilfe von Konkatenation
print "Guten Tag " + first_name + " " + last_name + "."

# Vermessung der Eingabe 
length = len(last_name)

# Ausgabe je nach Länge des Namens
if (length < 5):
	print "Auf Wiedersehen " + first_name + " !"
elif (length >= 5 and length <= 8):
	print "Auf Wiedersehen " + first_name + " " + last_name + " !"
else:
	print "Auf Wiedersehen " + last_name + " !"
