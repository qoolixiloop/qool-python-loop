#!/usr/bin/env python
# -*- coding: utf-8 -*-
#PCL I, Übung 3, HS15
#Aufgabe 3
#Autor: Irene
#Matrikel-Nr.: ***

SAC = {'Schoenenberger':'Rigi', 'Zueberbuehler':'Pizol', 'Stepankova':'Pizol', 'Schmid':'Flumserberge', 
		'Rutz':'Pilatus', 'Zimmerli':'Jungfrau', 'Bizirianis':'Pfannenstiel', 'Maurer':'Dom', 
		'Ferrari':'Eiger', 'Wiedmer':'Pfannenstock', 'Helbling':'Platthorn' , 'Blickenstorfer':'Weisshorn'}

SAC['Irene'] = "Artist's Drive"

SAC['Schoenenberger'] = 'Rigi'
print SAC
#Es wird nicht am Dictionary verändert, dieses Schlüssel-Wert-Paar schon existiert

SAC['Schoenenberger'] = 'Eiger'
print SAC
#Nur der Wert des Schlüssels 'Schoenenberg' ändert sich, da der Schlüssel schon
#exisitiert und so der Wert überschrieben wird

#Gib jeden Schlüssel und seinen Wert mit 
#einem Tabulator dazwischen aus
print "\nDie Schlüssel-Wert Paare:"
for key in SAC.keys():
	print key,"\t", SAC[key]

#Für jeden Schlüssel in der sortierten Liste von Schlüssel
#gib den Schlüssel aus, wenn der Wert länger ist als 5 Zeichen
print "\nDie Namen, deren Lieblingsberge einen Namen länger als 5 Zeichen haben:"
for key in sorted(SAC.keys()):
	if len(SAC[key]) > 5:
		print key


