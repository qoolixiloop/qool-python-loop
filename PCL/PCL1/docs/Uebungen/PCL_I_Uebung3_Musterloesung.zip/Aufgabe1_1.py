#!/usr/bin/env python
# -*- coding: utf-8 -*-
#PCL I, Übung 3, HS15
#Aufgabe 1.1
#Autor: Irene
#Matrikel-Nr.: ***

text = ['Programmieren', 'macht', '%', 'Spass', 'und', 'ist', 
			'sehr', 'spannend','.', 'Jetzt', 'wollen', 'wir', 'den', 
			'Umgang', 'mit', 'Listen', 'verstehen']

#a)
text.append('!')

#b)
mein_satz = ['Dies', 'ist', 'mein', 'Satz']
text.extend(mein_satz)

#c)
print text.count('ist')

#d)
text.remove('%')

#e)
text.insert(2, 'so')

#f)
text[0] = 'Computerlinguistik'

#g) findet Index von 'sehr' und ersetzt das Element an dieser Stelle
text[text.index('sehr')] = 'unglaublich'

print ' '.join(text)
