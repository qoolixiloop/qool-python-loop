#!/usr/bin/env python
# -*- coding: utf-8 -*-
#PCL I, Übung 3, HS15
#Aufgabe 3
#Autor: Irene
#Matrikel-Nr.: ***

import string

str = "gesundheitswiederherstellungsmittelmischungsverhaeltniskundiger"

for letter in str:
    letter_pos = string.lowercase.index(letter) #findet Postition des Buchstabens letter im Alphabet

    print letter * (letter_pos+1) #multipliziert Buchstabe mit seiner Position+1
    
