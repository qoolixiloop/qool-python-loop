#!/usr/bin/env python
# -*- coding: utf-8 -*-
#PCL I, Übung 3, HS15
#Aufgabe 2
#Autor: Irene
#Matrikel-Nr.: ***

import sys, operator, string

#nimm das Kommandozeilenargument an und benutze es als Dateinamen/Pfad. Öffne die Datei.
filename = sys.argv[1]
moby_dick = open(filename,'r')

my_dict = {}

#Gehe durch alle Zeilen in der Datei moby_dick
for line in moby_dick:
	line = line.split()
	for word in line:
	#b) Antwort: falls word schon ein Schlüssel in my_dict ist, wird dieses Schlüssel-Wert-Paar überschrieben
		if len(word) > 6:
			#b)
			if word not in my_dict:
				my_dict[word] = 1
			else:
				my_dict[word] += 1

#c) nach Schlüssel sortiert
for key in sorted(my_dict):
	print key,':',my_dict[key]

#c) nach Wert sortiert
sorted_val = sorted(my_dict.items(), key=operator.itemgetter(1))
for item in sorted_val:
	print item[0],':',item[1]

moby_dick.close()


