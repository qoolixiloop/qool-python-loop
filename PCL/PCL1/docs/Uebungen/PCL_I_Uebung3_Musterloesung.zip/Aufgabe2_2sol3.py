#!/usr/bin/env python
# -*- coding: utf-8 -*-
#PCL I, Übung 3, HS15
#Aufgabe 3
#Autor: Irene
#Matrikel-Nr.: ***

import string

str = "gesundheitswiederherstellungsmittelmischungsverhaeltniskundiger"

for letter in str:
    list = []
    letter_pos = string.lowercase.index(letter) #findet Postition des Buchstabens letter im Alphabet

    for i in range (0, letter_pos+1):
         list.append(letter)

    print ''.join(list)
    
