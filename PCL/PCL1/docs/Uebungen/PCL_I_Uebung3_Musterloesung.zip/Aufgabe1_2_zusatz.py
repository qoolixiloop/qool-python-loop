#!/usr/bin/env python
# -*- coding: utf-8 -*-
#PCL I, Übung 3, HS15
#Aufgabe 1.2
#Autor: Irene
#Matrikel-Nr.: ***

kafka = open('kafka_trial.txt', 'r')

#Wörter von kafka_trial.txt in eine Liste einfügen
kafka_clean = []
for line in kafka:
    line = line.split()
    kafka_clean.extend(line)

words = []
endings = []

while len(words) <= 150:
    ending = raw_input("Please enter a 4-letter ending you want to look for: \n")
    templist = []
    if len(ending) >= 4 and ending.isalpha() and ending not in endings:
        endings.append(ending) #speichere eingegebene Endung in endings
        count = 0
        for word in kafka_clean:
            #überprüfe, ob Wort diese Endung hat und füge es in templist ein, falls ja
            if len(word) >= 4 and word[-len(ending):] == ending:
                templist.append(word)
                count+=1
        #überprüfe, ob mehr als 5  Wörter gefunden wurden
        if len(templist) > 5:
            words.extend(templist)
            print "The ending '"+ending+"' was found ",count,"times."
        else:
            print "Sorry, only 5 or less words have this ending. Try again."
    else:
        print "OOPS: Your ending is invalid (length or characters). Please try again."


print "\nYou have found",len(words),"words!\n"

words_unique = list(set(words)) #einzigartige Wörter in einer Liste

print "You have looked for",len(endings), "endings:",endings
print "and found",len(words_unique), "unique words"

words_sorted = sorted(words_unique, key=len, reverse = True) #sortiere nach Länge der Strings

print "The 5 longest words found and their length:"
for i in range(5):
    print words_sorted[i]+'\t',len(words_sorted[i])

kafka.close()
