#!/usr/bin/env python
# -*- coding: utf-8 -*-
#PCL I, Übung 3, HS15
#Aufgabe 2
#Autor: Irene
#Matrikel-Nr.: ***

import random

#kreiert eine Liste mit 300 randomisierten Zahlen zwischen 1 und 600
numbers = []
for i in range(301):
	numbers.append(random.randint(1,600))

#Listen initiieren
even = []
odd = []

#ungerade und gerade Zahlen separieren
for n in numbers:
	n = int(n)
	if n%2 == 0:
		even.append(n)
	else:
		odd.append(n)

#Anzahl ausgeben
print "Anzahl gerade Zahlen: ", len(even)
print "Anzahl ungerade Zahlen: ", len(odd)

#sortiere die ungeraden und geraden Zahlen
even_sorted = sorted(even)
odd_sorted = sorted(odd)

#summiere die 5 grössten Zahlen von ungeraden und geraden Zahlen
even_sum = 0
odd_sum = 0

for num in even_sorted[-5:]:
	even_sum += num

for num in odd_sorted[-5:]:
	odd_sum += num

#Gib die Summe der ungeraden Zahlen aus, falls sie gleich gross oder
#grösser ist als die der geraden Zahlen, ansonsten die der geraden Zahlen
if odd_sum >= even_sum:
	print odd_sum, "ist die Summe der fünf grössten ungeraden Zahlen"
else:
	print even_sum, "ist die Summe der fünf grössten geraden Zahlen"

