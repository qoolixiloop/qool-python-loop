#!/usr/bin/env python
# -*- coding: utf-8 -*-

#PCL I, Übung 3, HS15
#Aufgabe 4_ReflexionFeedback
#Autor: Roland Benz
#Matrikel-Nr.: 97-923-163 


'''
Reflexion/Feedback
a) Fasse deine Erkenntnisse und Lernfortschritte in zwei Sätzen zusammen.
b) Wie viel Zeit hast du in diese Übungen investiert?
''' 

strTaskA="Lernfortschritte in Python: Alle Datentypen, Klassen (OOP),"\
	+ " Funktionen, Debugger pdb, Printformate, Exception-handling."
strTaskB="Etwa 25 Stunden, inkl. einlesen in Tutorials und ausprobieren.\n"\
	+ "Für Aufgabe2_1b) und die OOP Konzepte habe ich viel zu "\
	+ "lange gebraucht. \n"\
	+ "Die Aufgabe1_2 dauerte etwa 10 Stunden, da ich sie mehrmals machen "\
	+ "musste. Nach einiger Zeit merkte ich, dass das Buch nicht "\
	+ "vorhanden war. Als ich fertig war, ist pdb abgestürzt und hat "\
	+ "irgendeinen Buffer in die Datei geschrieben und einen Screenshot "\
	+ "des Bildschirms gemacht. Etwa 30% des Programms war darauf noch zu "\
	+ "sehen. Und als ich das nächste Mal fertig war, habe ich das Mail "\
	+ "von Irene gesehen mit dem anderen Buch im Anhang. (Nichts "\
	+ "in der Welt hätte mich dazu gebracht, das Programm nochmals um"\
	+ "zuschreiben. Dafür habe ich zur Sicherheit gleich als nächstes "\
	+ "die Dropbox eingerichtet. :-) )"

print "\nTask a)\n %s \n" %(strTaskA)
print "Task b)\n %s \n" %(strTaskB)
