#!/usr/bin/env python
# -*- coding: utf-8 -*-
#PCL I, Übung 5, HS15
#Aufgabe 6
#Autor: Dein Name
#Matrikel-Nr.: Deine Matrikel-Nr

from nltk.corpus import brown


#Dein Code


def main():
	words = [u'money', u'duty', u'love', u'heart']
	categories = [u'science_fiction', u'romance', u'government', u'humor', u'religion']
	#Dein Code


if __name__ == "__main__":
	main()