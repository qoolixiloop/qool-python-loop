#!/usr/bin/env python
# -*- coding: utf-8 -*-

import regex
import codecs

name_re = regex.compile(ur"([-\p{Lu}\sß'.]+)\s(\p{Lu}[\p{Ll}.].*?)[\n|\r]+")
"""
Regex to process european parliament members' first and last names.

Last names are in general all capitals. Additional characters that may occur
are punctuation like hyphens, apostrophes, or periods. Also, the German ß 
is treated as non-capitalizing, so it occurs in lowercase also in last names.

The last names are followed by a single whitespace.

The whitespace is followed by the given name(s). Given names usually begin with
a majuscule followed by a string of minuscules, but in several cases 
abbreviations of the form A. are used, so first names are detected as 
"uppercase letter, dot|lowercase letter, any until EOL".
"""

def process_line(line, name_re):
    """
    Return formatted entry for new names file.

    args:
        line: Unicode string in the form "LASTNAME Firstname\n"
        name_re: Compiled regex object.

    returns:
        Unicode string in the form "firstname\tlastname\tLASTNAME Firstname\n"
    """
    match = name_re.match(line)
    if match:
        # rstrip to remove trailing whitespace and newlines
        # this is necessary due to faulty entries and the codecs behavior
        # of coercing all files to binary mode, thus preventing normal UNL
        firstname = match.group(2).lower().rstrip()
        lastname = match.group(1).lower().rstrip()
        return u'{}\t{}\t{}'.format(firstname, lastname, line)
    else:
        return u''

if __name__ == '__main__':

    namelist = []

    with codecs.open('NAME.tsv', 'r', 'utf-8') as names:
        for line in names:
            namelist.append(process_line(line, name_re))

    with codecs.open('out.tsv', 'w', 'utf-8') as new_names:
        for line in namelist:
            new_names.write(line)
