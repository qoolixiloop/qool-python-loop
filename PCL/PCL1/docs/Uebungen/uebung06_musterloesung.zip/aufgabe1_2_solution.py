import unicodedata

class Normalstring(object):

    def __init__(self, ustr):
        self.unnormal = ustr
        self._ustr = self._normalize(ustr)

    def __eq__(self, other):
        if isinstance(other, Normalstring):
            if self._ustr == other._ustr:
                return True
            else:
                return False
        else:
            return NotImplemented
        
    def __getitem__(self, index):
        return self._ustr[index]

    def __contains__(self, uchr):
        if self._normalize(uchr) in self._ustr:
            return True
        else:
            return False

    def __str__(self):
        return self._ustr.__str__()

    def _normalize(self, ustr):
        nfd_ustr = unicodedata.normalize('NFD', ustr)
        return u''.join([uchr for uchr in nfd_ustr 
            if not unicodedata.combining(uchr)])

    def index(self, ustr):
        return self._ustr.index(self._normalize(ustr))
