#!/usr/bin/python
# -*- coding: utf-8 -*-

import codecs
import sys
from kitchen.text.converters import getwriter

UTF8Writer= getwriter('utf-8')
sys.stdout = UTF8Writer(sys.stdout)

infile=codecs.open('s.txt', 'r')
for line in infile:
	line= line.rstrip()

	print 'Line as STRING'
	print line,'[',type(line),']'
	print'-----------------------------'
	print 'Line as UNICODE'
	line=unicode(line, 'utf-8')
	print line , '[',type(line),']'
	print ''
infile.close()




